﻿app.controller('menuController', function ($scope) {
    //alert("teste");
})