﻿app.controller("homeController", function ($scope) {
    $scope.home = "homes";
})

